
# coding: utf-8

# # Text Classification with Recurrent Neural Networks, DBPedia dataset
# 
# Modified from original code here: https://github.com/tensorflow/tensorflow/blob/master/tensorflow/examples/learn/text_classification.py

# ### Make the notebook compatible with both Python 2 and 3
# 
# http://python-future.org/compatible_idioms.html

# In[1]:

from __future__ import absolute_import, division, print_function


# In[2]:

import numpy as np
import pandas as pd

import tensorflow as tf


# ### Plot graphs inline

# In[3]:

get_ipython().magic(u'matplotlib inline')

import matplotlib
import matplotlib.pyplot as plt


# In[4]:

print(tf.__version__)
print(np.__version__)
print(pd.__version__)
print(matplotlib.__version__)


# In[5]:

EMBEDDING_SIZE = 50
n_words = 0
MAX_LABEL = 15
WORDS_FEATURE = 'words'  # Name of the input words feature.


# ### Download the DBPedia dataset
# 
# http://wiki.dbpedia.org/Datasets
# 
# The dataset contains first paragraph of the wikipedia page for ~0.5M entities and the label is on of 15 categories. This is *topic classification*, each paragraph is labelled with the topic that it deals with.
# 
# Examples of topics:
# 
# * People
# * Companies
# * Creative Works
# * Universities/Colleges
# * Creative Works
# * etc.

# In[6]:

dbpedia = tf.contrib.learn.datasets.load_dataset(
      'dbpedia', size='large', test_with_fake_data=False)


# In[7]:

len(dbpedia.train.data)


# In[8]:

len(dbpedia.test.data)


# ### Data from DBPedia should be shuffled before use
# 
# * The data will be ordered, paragraphs from topic 1 will be at the beginning, topic 2 will be after that and so on
# * Shuffle the data before you use it for training or test

# In[9]:

# Randomly shuffle data
np.random.seed(10)
shuffle_indices = np.random.permutation(np.arange(len(dbpedia.train.data)))

data_shuffled = dbpedia.train.data[shuffle_indices]
target_shuffled = dbpedia.train.target[shuffle_indices]


# In[12]:

TRAIN_DATA = 500

train_data = data_shuffled[:TRAIN_DATA]
train_target = target_shuffled[:TRAIN_DATA]


# In[13]:

shuffle_indices = np.random.permutation(np.arange(len(dbpedia.test.data)))

data_shuffled = dbpedia.test.data[shuffle_indices]
target_shuffled = dbpedia.test.target[shuffle_indices]


# In[14]:

TEST_DATA = 50

test_data = data_shuffled[:TEST_DATA]
test_target = target_shuffled[:TEST_DATA]


# In[15]:

train_data[:5]


# ### Find the number of unique topics in the training set

# In[17]:

np.unique(dbpedia.train.target)


# In[19]:

x_train = pd.Series(train_data[:,1])
y_train = pd.Series(train_target)
x_test = pd.Series(test_data[:,1])
y_test = pd.Series(test_target)


# ### Word embeddings
# 
# In order to perform sentiment analysis or classifcation on text, each word is generally represented as an encoding. The encodings are typically done in such a way that words which appear together have codes which are close to each other.
# 
# Am encoding can be a numeric embedding (a low-dimensional representation), one-hot representation etc.
# 
# Word embeddings all have the same dimensionality which you can specify. A document is a vector of word embeddings (one dbpedia instance is a document in this case)
# 
# * Each document should be of the **same length**, we choose the length of the document to be equal to the length of the longest document
# * The other documents will be **padded** by a special symbol to be the same max length

# In[20]:

max_document_length_train = max([len(x.split(" ")) for x in x_train])
max_document_length_test = max([len(x.split(" ")) for x in x_test])

print(max_document_length_train, max_document_length_test)


# In[21]:

MAX_DOCUMENT_LENGTH = max(max_document_length_train,
                          max_document_length_test)


# ### Vocabulary processor
# 
# http://tflearn.org/data_utils/
# 
# Library to map every word which occurs in our dataset to a unique identifer. If there are 10023 words each will be assigned a unique id from 1-10023

# In[22]:

vocab_processor = tf.contrib.learn.preprocessing.VocabularyProcessor(
      MAX_DOCUMENT_LENGTH)


# In[23]:

x_train = np.array(list(vocab_processor.fit_transform(x_train)))
x_test = np.array(list(vocab_processor.transform(x_test)))


# In[24]:

x_train[:3]


# In[26]:

train_data[:1]


# In[27]:

n_words = len(vocab_processor.vocabulary_)
print('Total words: %d' % n_words)


# In[28]:

tf.reset_default_graph()


# ### EstimatorSpec defines the model you run
# 
# https://www.tensorflow.org/api_docs/python/tf/estimator/EstimatorSpec
# 
# Helper function to set up the estimator spec for prediction, training as well as evaluation of your model.
# 
# * *logits* output layer to which softmax activation is to be applied
# * *labels* training labels used to calculate the loss (we convert these labels to one-hot notation)
# * *mode* prediction, training or evaluation

# In[30]:

def estimator_spec_for_softmax_classification(logits, labels, mode):
    
    # Prediction mode
    predicted_classes = tf.argmax(logits, 1)
    if mode == tf.estimator.ModeKeys.PREDICT:
        return tf.estimator.EstimatorSpec(
            mode=mode,
            predictions= {
                'class': predicted_classes,
                'prob': tf.nn.softmax(logits)
            })

    # Training mode
    onehot_labels = tf.one_hot(labels, MAX_LABEL, 1, 0)
    loss = tf.losses.softmax_cross_entropy(
      onehot_labels=onehot_labels, logits=logits)

    if mode == tf.estimator.ModeKeys.TRAIN:
        optimizer = tf.train.AdamOptimizer(learning_rate=0.01)
        train_op = optimizer.minimize(loss, global_step=tf.train.get_global_step())
        return tf.estimator.EstimatorSpec(mode, loss=loss, train_op=train_op)

    # Evaluation mode
    eval_metric_ops = {
      'accuracy': tf.metrics.accuracy(
          labels=labels, predictions=predicted_classes)
    }

    return tf.estimator.EstimatorSpec(
          mode=mode, loss=loss, eval_metric_ops=eval_metric_ops)


# ### Define the RNN model
# 
# * *features* the training dataset features
# * *labels* the training labels
# * *mode* prediction, training or evaluation to be passed to the estimator spec method

# In[31]:

def rnn_model(features, labels, mode):
    # Convert indexes of words into embeddings.

    # This creates embeddings matrix of [n_words, EMBEDDING_SIZE] and then
    # maps word indexes of the sequence into [batch_size, sequence_length,
    # EMBEDDING_SIZE].
    word_vectors = tf.contrib.layers.embed_sequence(
      features[WORDS_FEATURE], vocab_size=n_words, embed_dim=EMBEDDING_SIZE)

    # Flatten esults to be a list of tensors [batch_size, EMBEDDING_SIZE]. This
    # is just a list of words
    word_list = tf.unstack(word_vectors, axis=1)

    # Create a Gated Recurrent Unit cell with hidden size of EMBEDDING_SIZE.
    cell = tf.contrib.rnn.GRUCell(EMBEDDING_SIZE)

    # Create an unrolled Recurrent Neural Networks to length of
    # MAX_DOCUMENT_LENGTH and passes word_list as inputs for each unit.
    _, encoding = tf.contrib.rnn.static_rnn(cell, word_list, dtype=tf.float32)

    # If you use a dynamic RNN you do not need to unstack the word_vectors,
    # it will be done under the hood for you
    #   _, encoding = tf.nn.dynamic_rnn(cell, word_vectors, dtype=tf.float32)

    # Given encoding of RNN, take encoding of last step (e.g hidden size of the
    # neural network of last step) and pass it as features for softmax
    # classification over output classes.

    logits = tf.layers.dense(encoding, MAX_LABEL, activation=None)
    return estimator_spec_for_softmax_classification(
      logits=logits, labels=labels, mode=mode)


# ### Instantiate an estimator with the RNN model

# In[32]:

classifier = tf.estimator.Estimator(model_fn=rnn_model)


# ### Train the RNN model
# 
# * The *numpy_input_fn* allows you to specify features and labels in the form of numpy arrays
# * We use full batch for training
# * Run for one epoch and shuffle the data

# In[33]:

train_input_fn = tf.estimator.inputs.numpy_input_fn(
      x={WORDS_FEATURE: x_train},
      y=y_train,
      batch_size=len(x_train),
      num_epochs=None,
      shuffle=True)
classifier.train(input_fn=train_input_fn, steps=100)


# ### Make predictions on test data

# In[40]:

test_input_fn = tf.estimator.inputs.numpy_input_fn(
      x={WORDS_FEATURE: x_test},
      y=y_test,
      num_epochs=1,
      shuffle=False)
predictions = classifier.predict(input_fn=test_input_fn)


# ### Reshape predicted data to be the same as original labels
# 
# This will allow us to compare the results for accuracy

# In[41]:

y_predicted = np.array(list(p['class'] for p in predictions))
y_predicted = y_predicted.reshape(np.array(y_test).shape)


# In[42]:

y_predicted


# ### Measure accuracy using scikit-learn and tensorflow

# In[45]:

from sklearn import metrics

score = metrics.accuracy_score(y_test, y_predicted)
print('Accuracy (sklearn): {0:f}'.format(score))


# In[46]:

scores = classifier.evaluate(input_fn=test_input_fn)
print('Accuracy (tensorflow): {0:f}'.format(scores['accuracy']))


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:



