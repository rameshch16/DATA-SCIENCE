  
# coding: utf-8

# # Income Classification using a Linear Classifier
# 
# Modified from original code here: https://www.tensorflow.org/tutorials/wide

# ### Make the notebook compatible with both Python 2 and 3
# 
# http://python-future.org/compatible_idioms.html

# In[15]:

from __future__ import absolute_import, division, print_function


# In[16]:

import pandas as pd
from six.moves import urllib
import shutil
import tensorflow as tf


# In[17]:

print(tf.__version__)
print(pd.__version__)


# ### Set up the file names where the training data and the test data are to be stored
# 
# Note that you'll have to manually create the "census" directory under the current working directory

# In[18]:

TRAIN_FILE_NAME = "census/adult.data"
TEST_FILE_NAME = "census/adult.test"


# ### Download and store the training and test data from the UCI Machine Learning Repository
# 
# There are a whole host of interesting datasets here: https://archive.ics.uci.edu/ml/index.php

# In[19]:

urllib.request.urlretrieve(
        "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data",
        TRAIN_FILE_NAME)


# In[20]:

urllib.request.urlretrieve(
        "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.test",
        TEST_FILE_NAME)


# ### The columns in the census data

# In[21]:

CSV_COLUMNS = [
    "age", "workclass", "fnlwgt", "education", "education_num",
    "marital_status", "occupation", "relationship", "race", "gender",
    "capital_gain", "capital_loss", "hours_per_week", "native_country",
    "income_bracket"
]


# ### Read training data into a dataframe
# 
# Sample and explore the data to understand what information is available. This will also be used to set up feature columns which will serve as an input to our linear classifier.

# In[22]:

df = pd.read_csv(
      TRAIN_FILE_NAME,
      names=CSV_COLUMNS,
      skipinitialspace=True,
      skiprows=1)


# In[23]:

df.head()


# ### Choose only those columns which seem relevant to predicting income
# 
# * Removed the "fnlwgt" column, the number of people the census takers believe that observation represents (sample weight)
# * Removed "capital_gain" and "capital_loss", continuous, dense columns usually work well with neural networks

# In[24]:

TRIMMED_REORDERED_COLUMNS = [
    "age", "workclass", "education", "education_num",
    "marital_status", "relationship", "race", "gender", "occupation", 
    "hours_per_week", "native_country", "income_bracket"
]


# In[25]:

df = df[TRIMMED_REORDERED_COLUMNS]


# In[26]:

df.head()


# ### Feature columns with categorical values
# 
# Find the unique values in a column and set up a categorical feature for those columns

# In[27]:

df['gender'].unique()


# In[28]:

df['race'].unique()


# In[29]:

df['education'].unique()


# In[30]:

df['marital_status'].unique()


# In[31]:

df['relationship'].unique()


# In[32]:

df['workclass'].unique()


# ### Set up categorical feature columns
# 
# Use *tf.feature_column.categorical_column_with_vocabulary_list* if the categorical columns have a finite set of values that we know in advance

# In[33]:

gender = tf.feature_column.categorical_column_with_vocabulary_list(
    "gender", ["Female", "Male"])

race = tf.feature_column.categorical_column_with_vocabulary_list(
    "race", ['White', 'Black', 'Asian-Pac-Islander', 'Amer-Indian-Eskimo', 'Other'])

education = tf.feature_column.categorical_column_with_vocabulary_list(
    "education", [
        "Bachelors", "HS-grad", "11th", "Masters", "9th",
        "Some-college", "Assoc-acdm", "Assoc-voc", "7th-8th",
        "Doctorate", "Prof-school", "5th-6th", "10th", "1st-4th",
        "Preschool", "12th"
    ])

marital_status = tf.feature_column.categorical_column_with_vocabulary_list(
    "marital_status", [
        "Married-civ-spouse", "Divorced", "Married-spouse-absent",
        "Never-married", "Separated", "Married-AF-spouse", "Widowed"
    ])

relationship = tf.feature_column.categorical_column_with_vocabulary_list(
    "relationship", [
        "Husband", "Not-in-family", "Wife", "Own-child", "Unmarried",
        "Other-relative"
    ])

workclass = tf.feature_column.categorical_column_with_vocabulary_list(
    "workclass", [
        "Self-emp-not-inc", "Private", "State-gov", "Federal-gov",
        "Local-gov", "?", "Self-emp-inc", "Without-pay", "Never-worked"
    ])


# ### Columns with continuous values
# 
# Use *tf.feature_column.numeric_column* to set up columns which have values in a numeric range

# In[34]:

age = tf.feature_column.numeric_column("age")

education_num = tf.feature_column.numeric_column("education_num")

hours_per_week = tf.feature_column.numeric_column("hours_per_week")


# ### Bucketed columns
# 
# Sometimes the relationship between a continuous feature and the label is not linear. A person's income may grow with age in the early stage of one's career, then the growth may slow at some point, and finally the income decreases after retirement. In this scenario, using the **raw age as a real-valued feature column** might not be a good choice because the model can only learn one of the three cases:
# 
# * Income always increases at some rate as age grows (positive correlation),
# * Income always decreases at some rate as age grows (negative correlation), or
# * Income stays the same no matter at what age (no correlation)
# 
# If we want to **learn the fine-grained correlation** between income and each age group separately, we can leverage bucketization. 
# 
# Bucketization is a process of dividing the entire range of a continuous feature into a set of consecutive bins/buckets, and then converting the original numerical feature into a bucket ID (as a categorical feature) depending on which bucket that value falls into. 

# In[35]:

age_buckets = tf.feature_column.bucketized_column(
    age, boundaries=[18, 25, 30, 35, 40, 45, 50, 55, 60, 65])


# ### Categorical column values might change over time

# In[36]:

df['occupation'].unique()


# In[37]:

df['native_country'].unique()


# ### Categorical columns with unknown values
# 
# If you don't know the list of categorical columns in advance then we use *tf.feature_column.categorical_column_with_hash_bucket* where every column value will be hashed to a unique integer.
# 
# The chances of collisions are usually low.

# In[38]:

occupation = tf.feature_column.categorical_column_with_hash_bucket(
    "occupation", hash_bucket_size=1000)

native_country = tf.feature_column.categorical_column_with_hash_bucket(
    "native_country", hash_bucket_size=1000)


# ### Base columns which use the raw values from the dataset

# In[142]:

base_columns = [
    gender, race, marital_status, workclass, occupation,
    native_country, age_buckets, education
]


# ### Crossed columns express more complex relationships between data
# 
# Some relationships between individual features and the output maybe hard to define. Two or more features considered together might have a more direct impact on the output. Feature crosses are **engineered features** which allows you to specify this more complex relationship.
# 
# Education and occupation when considered together will be a better predictor of income than either of them alone.

# In[143]:

crossed_columns = [
    tf.feature_column.crossed_column(
        ["education", "occupation"], hash_bucket_size=1000),
    tf.feature_column.crossed_column(
        [age_buckets, "education", "occupation"], hash_bucket_size=1000),
    tf.feature_column.crossed_column(
        ["native_country", "occupation"], hash_bucket_size=1000)
]


# ### Continuous valued columns
# 
# If these columns are dense they are more suitable for deep neural networks

# In[144]:

deep_columns = [
    education_num,
    hours_per_week
]


# ### The input function in an estimator maps the features and the corresponding labels
# 
# The standard library method *tf.estimator.inputs.pandas_input_fn* allows us to specify feature data as a pandas dataframe and the labels as a list.
# 
# The input function specifies the features and labels for training
#     

# In[145]:

def input_fn(file_name, num_epochs, shuffle):
  df = pd.read_csv(
      file_name,
      names=CSV_COLUMNS,
      skipinitialspace=True,
      skiprows=1)
  df = df[TRIMMED_REORDERED_COLUMNS]  
  
  # Remove NaN elements
  df = df.dropna(how="any", axis=0)

  # Use numeric labels to represent incomes below and above 50K
  labels = df["income_bracket"].apply(lambda x: ">50K" in x).astype(int)
  
  return tf.estimator.inputs.pandas_input_fn(
      x=df,
      y=labels,
      batch_size=100,
      num_epochs=num_epochs,
      shuffle=shuffle,
      num_threads=5)


# In[146]:

MODEL_DIR = "./linear_classifier"


# ### Remove the old saved model so we generate entirely new parameters

# In[147]:

shutil.rmtree(MODEL_DIR)


# ### Pass in all 3 sets of columns
# 
# For this model, the base columns are the ones which really affect the output

# In[148]:

linear_estimator = tf.estimator.LinearClassifier(
        model_dir=MODEL_DIR, feature_columns=base_columns)


# In[149]:

linear_estimator.train(
      input_fn=input_fn(TRAIN_FILE_NAME, num_epochs=None, shuffle=True),
      steps=1000)


# ### Evaluate the test data and predict the income levels of the adults

# In[150]:

results = linear_estimator.evaluate(
      input_fn=input_fn(TEST_FILE_NAME, num_epochs=1, shuffle=False),
      steps=None)


# In[151]:

for key in sorted(results):
    print("%s: %s" % (key, results[key]))


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:



