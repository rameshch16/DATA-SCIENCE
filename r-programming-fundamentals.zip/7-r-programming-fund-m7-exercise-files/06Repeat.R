WriteOnNoteBook <- function()
{
  count <- 0
  repeat {
    count <- count + 1
    print(paste("writing on page number",count))
  }
}

WriteOnNoteBook()