update.packages()
update.packages(ask = FALSE)
remove.packages("ggplot2")
remove.packages(c("sos","ggplot2"))