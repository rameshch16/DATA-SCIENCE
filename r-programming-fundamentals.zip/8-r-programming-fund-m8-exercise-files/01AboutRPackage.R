library() #List all installed packages
packages <- installed.packages()