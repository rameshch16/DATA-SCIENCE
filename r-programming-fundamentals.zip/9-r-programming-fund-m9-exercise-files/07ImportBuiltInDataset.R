library(datasets)
data(package="datasets")
data(iris)
str(iris)
