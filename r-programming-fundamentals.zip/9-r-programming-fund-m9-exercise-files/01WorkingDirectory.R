#Set working directory
getwd() #get working directory
setwd("F:\\PS\\R\\Mod9") #windows
setwd("F:/PS/R/Mod9") #windows
setwd("/Users/UserName/Documents/Folder") #on mac or linux
setwd(file.path("F:","PS","R","Mod9")) 