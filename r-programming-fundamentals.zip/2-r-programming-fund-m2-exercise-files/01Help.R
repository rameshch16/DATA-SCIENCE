help(rnorm) #search exact term 
example(rnorm) #Use example in the documentation
?rnorm #short syntax to search exact term
help.search("rnorm") #search similar terms
??rnorm #short syntax to search similar terms
