demo() #List demonstrations in attached packages
demo(package = .packages(all.available = TRUE)) #List demonstrations in all installed packages
demo(package = 'graphics') #List demonstrations in graphics package
demo(graphics) #demonstrate graphics 
