#Logical operators
5 > 2  #greater than
5 >= 2 #greater than equal to 
5 < 2  #less than
5 <=2  #less than equal to
5 == 2 #exactly equal to
5 != 2 #not equal to
"b" > "a" #comparing characters
!(TRUE) #logical NOT operator
TRUE | FALSE #logical OR operator
TRUE & FALSE #logical AND Operator