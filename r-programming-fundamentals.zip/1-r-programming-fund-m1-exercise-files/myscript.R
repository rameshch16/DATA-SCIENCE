print("hello world")
mean(1:20)
x <- 1:20
mean(x)
