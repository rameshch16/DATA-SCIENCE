library(datasets)
data(iris)
median(iris$Sepal.Length)