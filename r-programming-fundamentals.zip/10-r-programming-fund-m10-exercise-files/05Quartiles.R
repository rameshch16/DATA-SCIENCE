library(datasets)
data(iris)
summary(iris$Sepal.Length)
summary(iris)