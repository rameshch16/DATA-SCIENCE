library(datasets)
data(iris)
str(iris)
head(iris)