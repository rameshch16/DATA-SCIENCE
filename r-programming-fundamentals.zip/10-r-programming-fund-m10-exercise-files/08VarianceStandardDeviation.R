library(datasets)
data(iris)
var(iris$Sepal.Length)
sd(iris$Sepal.Length)