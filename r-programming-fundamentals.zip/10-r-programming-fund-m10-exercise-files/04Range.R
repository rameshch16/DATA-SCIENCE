library(datasets)
data(iris)
range(iris$Sepal.Length)
diff(range(iris$Sepal.Length))