library(datasets)
data(iris)
mean(iris$Sepal.Length)