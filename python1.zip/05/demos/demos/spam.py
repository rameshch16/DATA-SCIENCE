def add_spam(menu=[]):
    menu.append("spam")
    return menu
