from flight_duration import Flight,airports
from recurring_flights import flights
from datetime import datetime
import sqlite3

conn = sqlite3.connect(':memory:', detect_types=sqlite3.PARSE_DECLTYPES)
cur = conn.cursor()

cur.execute('CREATE TABLE flight('
            'flight_id TEXT, '
            'origin TEXT,'
            'destination TEXT,'
            'departure TIMESTAMP,'
            'arrival TIMESTAMP)')

