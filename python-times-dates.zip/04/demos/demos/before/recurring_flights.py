from datetime import time, timedelta, datetime
import dateutil.rrule as dr
import dateutil.relativedelta as relativedelta
import pytz

from flight_duration import airports, Flight


class FlightGenerator:
    def __init__(self, flight_id, origin, destination, duration):
        self.flight_id = flight_id
        self.origin = origin
        self.destination = destination
        self.duration = duration

