import calendar
import flight_duration


class FlightsCalendar(calendar.TextCalendar):

    def __init__(self, firstweekday, flights):
        super(FlightsCalendar, self).__init__(firstweekday)

c = FlightsCalendar(calendar.MONDAY, flight_duration.flights)
s = c.formatmonth(2018, 1)

print(s)
