set.seed(72)

# standard data.frame from R Base
mydf = data.frame(a = c("Paul", "Kim", "Nora", "Sue", 
                        "Paul", "Kim"), 
                    b = c("A", "A", "B", "B", "B", "C"),
                    c = rnorm(2)); mydf

# data.table

library(data.table)

set.seed(72)

mytable = data.table(a = c("Paul", "Kim", "Nora", "Sue", 
                           "Paul", "Kim"), 
                     b = c("A", "A", "B", "B", "B", "C"),
                     c = rnorm(2)); mytable


head(mydf)

sapply(mydf, class)

head(mytable)

sapply(mytable, class)

# checking the class
class(mydf); class(mytable)





### Extracting elements from the data.frame/table

# rows
mydf[3,]

mytable[3,]

# what is the default extract when using simple box brackets?
mydf[3]

mytable[3]
# df extracts columns, dt rows

# columns: extraction in different form, column or vector
mydf[3]; mydf[,3]

mytable[,3] # dt output

mytable[,c] # use the column name, this is paramater j of dt syntax

mytable[,.(c)] # in this notation you will get a dt as ouput again

mytable[, list(c)] # gives the same output, . and list are aliases

mytable[,.(cname = c)] # same command but renaming the column

mytable[, sum(b == "B")] # how many rows with "B"?
# with a dt we can do calculations in parameter j

mytable[b =="B", .N] # an alternative way with .N as number indicator

length(mydf[mydf$b == "B",]) # doing it the old data.frame way

# selecting all rows with character A in col b
mytable[b == "A",]

subset(mytable, b =="A") # same result with the subset command

subset(mytable, b =="A", select = a) # use select for a specific column

mydf[mydf$b == "A",] # the name of the df needs to be stated here





### Combining paramters

mytable[3:6, sum(c)] # sum col c from rows 3 to 6

mytable[!3:6, sum(c)] # sum col c except rows 3 to 6

## using the by parameter
mytable[, by = b, .N] # count of the 3 types of b

mytable[, by = .(b,a), .N] # grouped by b and a

transpose(mytable) # transpose works on nearly all R objects (df, dt, lists)

mytable[order(-b, -a)] # ordering with order, b and a each descending

setorder(mytable, -b,-a) # ordering descending, first b, then a
# note that set... functions in the dt package modify the data
mytable




# converting a data frame to a data table is easy
newmt = data.table(mtcars); class(newmt)

# lets check which dt we have stored so far
tables()

# we can use an apply function to get each vector class
sapply(mytable, class)






### Keys

# set a key (at column a) to organize the table
mytable # note the order of col a

setkey(mytable, a)
mytable # now the dataset is ordered alphabetically according to a 

key(mytable) # lets check which column the key is at

mytable["Kim"] # now we can directly get access to rows by calling row values

mytable["A"] # this is only possible in the key column

mytable[c("Kim", "Paul")] # of course we can get several key-values in a vector

mytable["Kim", .(c)] # lets now add the j parameter - here I am stating that
# I only want column c as an output on "Kim", and it should be a data.table
# therefore the list alias

mytable["Kim", c] # without the list alias we only get a vector







### Querying a big dataset

library(ggplot2) # for diamonds

library(data.table)

?diamonds

newdiam = data.table(diamonds); class(newdiam)

newdiam

summary(newdiam)

# 2 different ways how to find out how many diamonds >10000 in price

# how many diamonds >10K in price, sorted by color

# table with diamonds cut = "Idea" and the color is either "E" or "J"

# order the table by price

# extract a table with price and cut

# how many diamonds have combined xyz dimensions (sum) of > 18 ?

# get the mean price for diamonds with a cut of "Ideal" and "Premium"

# get the number of diamonds with a price >10000 and a cut of "Premium"





# 2 different ways: how many diamonds >10000 in price?

nrow(subset(newdiam, price > 10000))

newdiam[price>10000,.N]

# how many diamonds >10K in price, sorted by color?

newdiam[price>10000,.N, by = color]

# table with diamonds cut = "Idea" and the color is either "E" or "J"

newdiam[cut == "Ideal" & (color == "E" | color == "J")]

# order the table by price

newdiam[order(price)]

# extract a table with price and cut

newdiam[, .(price, cut)]

# how many diamonds have combined xyz dimensions (sum) of > 18 ?

newdiam[, sum((x + y + z)>18)]

newdiam[(x + y + z)>18, .N]

# get the mean price for diamonds with a cut of "Ideal" and "Premium"

newdiam[cut == "Ideal" | cut == "Premium", .(meanprice = mean(price)), by = cut] # keep it a list to name the output

# get the number of diamonds with a price >10000 and a cut of "Premium

newdiam[ price > 10000 & cut =="Premium", .N]

newdiam[, .N, price > 10000 & cut =="Premium"]


