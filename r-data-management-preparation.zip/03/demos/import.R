
# Data Import

class(Insects)

numbers = scan()

characters = scan(what = "character")






# Using the fread function
library(data.table)

mydata = fread("Insects.csv");mydata

df = fread("region	< 10 g	10 - 20 g	20 - 30 g	30 - 40 g	> 40 g
Welsh Creek	5	34	54	23	8
           River Inn	72	33	28	35	9
           Spur Forest	34	65	23	67	2
           Hamock Flats	28	23	34	45	11
           Gelb Rocks	34	68	23	58	9
           "); df


df = fread("region	< 10 g	10 - 20 g	20 - 30 g	30 - 40 g	> 40 g
Welsh Creek	5	34	54	23	8
           River Inn	72	33	28	35	9
           Spur Forest	34	65	23	67	2
           Hamock Flats	28	23	34	45	11
           Gelb Rocks	34	68	23	58	9
           ",
           col.names =c("Region", "Class1", 
                        "Class2", "Class3", "Class4", "Class5"))

df; class(df)







# Using "foreign"

mydt = read.dta("statatest.dta"); mydt





# Simple data.frame
mydata.frame = data.frame(name = c("Paul", "Kim", 
                                   "Nora", "Sue", 
                                   "Pat", "Kyle"), 
                          counts = c(3,5),
                          measurement = rnorm(6)) 
mydata.frame


# Strings and integers converted
mydata.frame = data.frame(name = c("Paul", "Kim", 
                                   "Nora", "Sue", 
                                   "Pat", "Kyle"), 
                          counts = as.integer(c(3,5)),
                          measurement = rnorm(6),
                          stringsAsFactors = F) 

mydata.frame






# get the library - only once
install.packages("data.table")

# activation

library(data.table)

mytable = data.table(a = c("Paul", "Kim", "Nora", "Sue", "Paul", "Kim"), 
                     b = c("A", "A", "B", "B", "B", "C"),
                     c = rnorm(2)); mytable

sapply(mytable, class)


# data_frame

library(dplyr)

my_df = data_frame(a = c("Paul", "Kim", "Nora", "Sue", "Paul", "Kim"), 
                   b = c("A", "A", "B", "B", "B", "C"),
                   c = rnorm(6)); my_df # length 6


sapply(my_df, class)


# checking the class
class(mytable); class(my_df)






