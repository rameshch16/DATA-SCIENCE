
### Cleaning your data with tidyr, reshape2 and dplyr

library(tidyr)

library(dplyr) 

library(reshape2)

# import as csv, make sure to have heading activated
# if there is no heading R might not recognize all columns
# name for easy coding

head(insec)

# fix the header
names(insec) <- c("Region", "<10g", 
                  "10-20g", "20-30g", 
                  "30-40g", ">40g") 

insec

?gather

# Converting to long form by using "gather"
gather(data = insec, key = weight, value = counts, -Region)

# we are specifying the dataset 
# key is the different weights in one column
# we put all the counts in 1 column 
# we suppress a gathering of Region


# store it as a table
insec.table = tbl_df(gather(data = insec, 
        key = weight, value = counts, -Region))

# we can of course change the order with the arrange function
arrange(insec.table, Region)

## alternative with package reshape2

library(reshape2)

insec.melt = melt(data = insec, measure.vars = c(2:6), # here we use col IDs
                 variable.name = "weight", 
                 value.name = "counts"); insec.melt











# multiple information in 1 cell - splitting cells

doubleinfo <- data.frame(
  name = c("Ted", "Pauline", "Vera", 
           "Angela", "Frank", "Pam"),
  biometrics = c("179m", "173f", 
                 "174f", "159f", "188m", "163f"),
  measurement = runif(6)); doubleinfo

# biometrics contains height in cm 
# and sex (2 variables)
# this often requires separation

# use "separate" from tidyr to split biometrics
separate(data = doubleinfo, col = biometrics,
         into = c("height", "sex"), 3)
# number 3 indicates split 
# pos starts from left, - from right







# From long form to wide form: 2 variables in one column

perf <- data.frame(
  name = c("Pam", "Pam", "Nick", "Nick", "Kyle", "Kyle"),
  performance = c("top", "low", "top", "low", "top", "low"),
  counts = c(13,4,12,2,9,5)); perf

# We have 2 variables ,the top and low performance, in 1 column
# how do we split a column?

spread(data=perf, key = performance, value = counts)

## The alternative from the reshape2 package "dcast"

# the arguments differ a bit
dcast(data = perf, name ~ performance, value.var = "counts" )







### 2 Table Verbs - Joins

df1 <- data.frame(name = c("Tom", "Ted", "Sue", "Frank", "Jim"), 
                  height =c(177, 173, 181, 169, 188), 
                  category =c("A", "F", "L", "A", "I"),
                  stringsAsFactors = F) 

df2 <- data.frame(name = c( "Amy", "Sue", "Nataly", "Jim"), 
                  weight =c(69, 55, 78, 81),
                  stringsAsFactors = F)

head(df1); head(df2)

library(dplyr) # the functions are part of dplyr

# Mutating Joins

inner_join(df1, df2)

left_join(df1, df2)

right_join(df1, df2)

left_join(df2, df1) # same result but different order

full_join(df1, df2)

# Filtering Joins

anti_join(df1, df2)

semi_join(df1, df2)


